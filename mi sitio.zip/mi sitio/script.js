document.addEventListener("DOMContentLoaded", () => {
    
    // mensaje bienvenida
    console.log("¡Bienvenido a la página informativa!");

    // cambiar modo
    const btnModo = document.getElementById("btn-modo");
    if (btnModo) {
        btnModo.addEventListener("click", () => {
            document.body.classList.toggle("modo-oscuro");
            if (document.body.classList.contains("modo-oscuro")) {
                btnModo.innerText = "☀️ Modo Claro";
            } else {
                btnModo.innerText = "🌙 Modo Oscuro";
            }
        });
    }

    // cambiar tamaño
    const btnFuente = document.getElementById("btn-fuente");
    let letraGrande = false;
    if (btnFuente) {
        btnFuente.addEventListener("click", () => {
            letraGrande = !letraGrande;
            document.body.style.fontSize = letraGrande ? "1.2rem" : "1rem";
        });
    }

    // menu interactivo
    const btnSaludar = document.getElementById("btn-saludo");
    if (btnSaludar) {
        btnSaludar.addEventListener("click", () => {
            const nombre = prompt("¿Cuál es tu nombre?");
            if (nombre) {
                alert(`¡Hola ${nombre}! Gracias por visitar la página sobre Milo J.`);
            }
        });
    }

    // 5. Botón para volver arriba
    const btnArriba = document.getElementById("btn-arriba");
    if (btnArriba) {
        btnArriba.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }
});